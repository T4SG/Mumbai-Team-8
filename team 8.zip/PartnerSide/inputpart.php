<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
}
</style>
</head>
<body>

<table>
  <tr>
    <th>Phases</th>
    <th>Percentage Completed</th>		
    <th>Comments/Issues</th>
    <th>Images</th>
  </tr>
  <tr>
    <td>Site Preparation</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Soil Preparation</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Concrete Bed Layer</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Brick Walls</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Finishes Walls</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Finishes Ceilings</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  <tr>
  <tr>
    <td>Finishes Floors</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
 </tr>
  <tr>
    <td>Doors-Carpentry</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
 <tr>
  <tr>
    <td>Finishes-Windows</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
 </tr>
  <tr>
    <td>Locksmith Work</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
 <tr>
  <tr>
    <td>Glass for Windows</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Internal Painting</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  <tr>
  <tr>
    <td>Electric work</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Electric Appliances</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  <tr>
  <tr>
    <td>Sink and Water Plumbing</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>External Walls Painting</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  <tr>
  <tr>
    <td>Plaque Install</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>Soil Preparation</td>
    <td><input = "text" name = "Percentage Completed"></td>
    <td><textarea name= "Comment" cols="20" rows="3"></textarea></td>
  <tr>
</table>
<br>
<br>
<center>
<input type="Submit"/>
</center>
</body>
</html>
