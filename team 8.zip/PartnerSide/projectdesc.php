<!DOCTYPE html>
<html>
<head>
<style>
#header {
    background-color:black;
    color:white;
    text-align:center;
    padding:5px;
}
#nav {
    line-height:30px;
    background-color:#eeeeee;
    height:300px;
    width:100px;
    float:left;
    padding:5px;	      
}
#section {
    width:350px;
    float:left;
    padding:10px;	 	 
}
#footer {
    background-color:black;
    color:white;
    clear:both;
    text-align:center;
   padding:5px;	 	 
}
</style>
</head>
<body>

<div id="header">
<h1>Progress Report</h1>
</div>

<div id="nav">
<button type = "button">Project 1</button><br>
<button type = "button">Project 2</button><br>
<button type = "button">Project 3</button><br>
<button type = "button">Project 4</button><br>
</div>

<div id="section">
<button onclick = "window.location.href='file:///C:/Users/Admin/Desktop/New%20folder/inputpart.html'">Detailed Information</button><br>
<button onclick = "window.location.href='file:///C:/Users/Admin/Desktop/New%20folder/quickup.html'">Quick Updation</button><br>
</div>

<div id="footer">
<input type = "Submit">
</div>

</body>
</html>
