<!DOCTYPE html>
<html>
<head>
<style>

th, td {
    padding: 15px;
}
</style>
</head>
<body>

    <h>Description</h> <textarea name="text" cols=20 rows=3></textarea>
    <br>
    <h>Images</h> 
    <br>
    <h>Need more capital?</h>
    <br>
    <ul>
	<li><button type="button">Yes</button></li>
	<li><button type = "button">No</button></li>
    </ul>
    <br>
    <input type="Submit"/>
	
    
 

</body>